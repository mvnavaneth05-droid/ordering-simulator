"""Hand-crafted scenarios (deterministic) and a random workload generator."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from .core import Simulator


@dataclass
class Scenario:
    name: str
    title: str
    description: str
    n: int
    build: Callable[[Simulator], None]


def _fifo(sim):
    # P1 sends A then B to P0/P2, but A is slow and B is fast.
    for d in (0, 2):
        sim.set_delay(1, d, "A", 10)
        sim.set_delay(1, d, "B", 2)
    sim.broadcast_at(0, 1, "A")
    sim.broadcast_at(1, 1, "B")


def _causal(sim):
    # P0 sends m1 (slow to P2). P1 receives m1 quickly and replies m2.
    # m1 -> m2, but m2 reaches P2 first.
    sim.set_delay(0, 1, "m1", 2)
    sim.set_delay(0, 2, "m1", 20)
    sim.set_delay(1, 0, "m2", 1)
    sim.set_delay(1, 2, "m2", 2)

    def reply(proc, msg):
        if proc.pid == 1 and msg.label == "m1":
            proc.broadcast("m2")
    sim.procs[1].on_deliver = reply
    sim.broadcast_at(0, 0, "m1")


def _total(sim):
    # P1 and P2 broadcast concurrently (neither causally precedes the other).
    sim.set_delay(1, 2, "X", 3)
    sim.set_delay(2, 1, "Y", 3)
    sim.set_delay(1, 3, "X", 1)
    sim.set_delay(2, 3, "Y", 6)
    sim.broadcast_at(0, 1, "X")
    sim.broadcast_at(0, 2, "Y")


SCENARIOS = {
    "fifo": Scenario("fifo", "FIFO violation",
                     "P1 sends A then B; the network delivers B first.", 3, _fifo),
    "causal": Scenario("causal", "Causal violation",
                       "m1 -> m2 (P1 replies after seeing m1) but m2 overtakes m1 on its way to P2.", 3, _causal),
    "total": Scenario("total", "Total-order violation",
                      "Concurrent broadcasts X, Y: different processes see different orders.", 4, _total),
}


def run_scenario(name: str, protocol: str, seed: int = 0) -> Simulator:
    sc = SCENARIOS[name]
    sim = Simulator(sc.n, protocol, seed)
    sc.build(sim)
    return sim.run()


def run_random(protocol: str, n: int = 4, msgs: int = 15, seed: int = 0,
               reply_prob: float = 0.4, horizon: float = 20.0) -> Simulator:
    """Random broadcasts; with probability reply_prob a receiver reacts with a
    reply, creating genuine causal chains."""
    sim = Simulator(n, protocol, seed)
    wl = sim.rng.__class__(seed + 10_000)    # workload RNG independent of network RNG
    counts = [0] * n
    for _ in range(msgs):
        p = wl.randrange(n)
        counts[p] += 1
        sim.broadcast_at(wl.uniform(0, horizon), p, f"P{p}#{counts[p]}")

    reply_rng = sim.rng.__class__(seed + 20_000)

    def maybe_reply(proc, msg):
        if msg.sender != proc.pid and not msg.label.startswith("re:") \
                and reply_rng.random() < reply_prob:
            proc.broadcast(f"re:{msg.label}@P{proc.pid}")
    for p in sim.procs:
        p.on_deliver = maybe_reply
    return sim.run()
