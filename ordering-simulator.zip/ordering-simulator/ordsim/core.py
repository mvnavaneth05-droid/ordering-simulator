"""Discrete-event simulation kernel: processes, network, event log."""
from __future__ import annotations

import heapq
import itertools
import random
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional, Tuple


@dataclass(frozen=True)
class Message:
    label: str            # unique application-level id, e.g. "A" or "P1#3"
    sender: int
    kind: str = "data"    # "data" | "req" (to sequencer) | "ordered" (from sequencer)
    seq: int = 0          # per-sender sequence number   (FIFO)
    vc: Tuple[int, ...] = ()  # vector timestamp         (causal)
    gseq: int = 0         # global sequence number       (total)


@dataclass(frozen=True)
class Event:
    kind: str             # "send" | "recv" | "deliver"
    time: float
    pid: int
    label: str
    note: str = ""


class Process:
    """A node. Subclasses implement broadcast() and receive()."""

    name = "base"

    def __init__(self, pid: int, sim: "Simulator"):
        self.pid, self.sim, self.n = pid, sim, sim.n
        self.delivered: List[str] = []
        self.on_deliver: Optional[Callable[["Process", Message], None]] = None

    # ---- protocol interface -------------------------------------------
    def broadcast(self, label: str) -> None:
        raise NotImplementedError

    def receive(self, msg: Message) -> None:
        raise NotImplementedError

    # ---- helpers ------------------------------------------------------
    def others(self) -> List[int]:
        return [d for d in range(self.n) if d != self.pid]

    def send_to(self, dst: int, msg: Message) -> None:
        self.sim.transmit(self.pid, dst, msg)

    def log_send(self, label: str) -> None:
        self.sim.log.append(Event("send", self.sim.now, self.pid, label))

    def deliver(self, msg: Message) -> None:
        """Hand a message to the application (this is what orderings constrain)."""
        self.sim.log.append(Event("deliver", self.sim.now, self.pid, msg.label))
        self.delivered.append(msg.label)
        if self.on_deliver:
            self.on_deliver(self, msg)


class Simulator:
    """Event-driven simulator with a non-FIFO network (random per-message delay)."""

    def __init__(self, n: int, protocol: str, seed: int = 0,
                 min_delay: float = 1.0, max_delay: float = 10.0):
        from .protocols import PROTOCOLS
        self.n, self.protocol = n, protocol
        self.now = 0.0
        self.log: List[Event] = []
        self.rng = random.Random(seed)
        self.min_delay, self.max_delay = min_delay, max_delay
        self.delays: Dict[Tuple[int, int, str], float] = {}
        self._queue: list = []
        self._counter = itertools.count()
        self.procs: List[Process] = [PROTOCOLS[protocol](i, self) for i in range(n)]

    # ---- scheduling ---------------------------------------------------
    def schedule(self, delay: float, fn, *args) -> None:
        heapq.heappush(self._queue, (self.now + delay, next(self._counter), fn, args))

    def broadcast_at(self, t: float, pid: int, label: str) -> None:
        self.schedule(t - self.now, self.procs[pid].broadcast, label)

    def set_delay(self, src: int, dst: int, label: str, delay: float) -> None:
        """Force the network delay of one (src, dst, label) transmission."""
        self.delays[(src, dst, label)] = delay

    # ---- network ------------------------------------------------------
    def transmit(self, src: int, dst: int, msg: Message) -> None:
        d = self.delays.get((src, dst, msg.label))
        if d is None:
            d = self.rng.uniform(self.min_delay, self.max_delay)
        self.schedule(d, self._arrive, dst, msg)

    def _arrive(self, dst: int, msg: Message) -> None:
        self.log.append(Event("recv", self.now, dst, msg.label, msg.kind))
        self.procs[dst].receive(msg)

    # ---- run ----------------------------------------------------------
    def run(self) -> "Simulator":
        while self._queue:
            t, _, fn, args = heapq.heappop(self._queue)
            self.now = t
            fn(*args)
        return self
