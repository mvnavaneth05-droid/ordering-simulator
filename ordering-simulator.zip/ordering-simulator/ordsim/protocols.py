"""Four broadcast protocols over the same unreliable-order network."""
from __future__ import annotations

from collections import defaultdict
from dataclasses import replace

from .core import Message, Process


class NoOrdering(Process):
    """Baseline: deliver in arrival order. Guarantees nothing."""
    name = "raw"

    def broadcast(self, label):
        m = Message(label, self.pid)
        self.log_send(label)
        for d in self.others():
            self.send_to(d, m)
        self.deliver(m)

    def receive(self, m):
        self.deliver(m)


class FifoOrdering(Process):
    """FIFO: per-sender sequence numbers + hold-back queue."""
    name = "fifo"

    def __init__(self, pid, sim):
        super().__init__(pid, sim)
        self.seq = 0
        self.expected = defaultdict(lambda: 1)   # next seq to deliver per sender
        self.buffer = {}                          # (sender, seq) -> Message

    def broadcast(self, label):
        self.seq += 1
        m = Message(label, self.pid, seq=self.seq)
        self.log_send(label)
        for d in self.others():
            self.send_to(d, m)
        self.deliver(m)

    def receive(self, m):
        s = m.sender
        self.buffer[(s, m.seq)] = m
        while (s, self.expected[s]) in self.buffer:
            nxt = self.buffer.pop((s, self.expected[s]))
            self.expected[s] += 1
            self.deliver(nxt)


class CausalOrdering(Process):
    """Causal: Birman-Schiper-Stephenson vector clocks.

    vc[k] = number of messages from process k delivered here (own sends count
    as delivered). m from s is deliverable iff
        m.vc[s] == vc[s] + 1            (next message from s)
        m.vc[k] <= vc[k]  for k != s    (everything s had seen, we have seen)
    """
    name = "causal"

    def __init__(self, pid, sim):
        super().__init__(pid, sim)
        self.vc = [0] * self.n
        self.holdback = []

    def broadcast(self, label):
        self.vc[self.pid] += 1
        m = Message(label, self.pid, vc=tuple(self.vc))
        self.log_send(label)
        for d in self.others():
            self.send_to(d, m)
        self.deliver(m)

    def _ready(self, m):
        s = m.sender
        return m.vc[s] == self.vc[s] + 1 and all(
            m.vc[k] <= self.vc[k] for k in range(self.n) if k != s)

    def receive(self, m):
        self.holdback.append(m)
        progress = True
        while progress:
            progress = False
            for h in list(self.holdback):
                if self._ready(h):
                    self.holdback.remove(h)
                    self.vc[h.sender] += 1
                    self.deliver(h)
                    progress = True
                    break


class TotalOrdering(Process):
    """Total order via a fixed sequencer (process 0).

    Every broadcast goes to the sequencer, which stamps a global sequence
    number and fans it out. Everyone (including the sender) delivers strictly
    in global-sequence order, using a hold-back queue.
    """
    name = "total"
    SEQUENCER = 0

    def __init__(self, pid, sim):
        super().__init__(pid, sim)
        self.next_gseq = 1        # sequencer state
        self.next_deliver = 1     # receiver state
        self.buffer = {}

    def broadcast(self, label):
        req = Message(label, self.pid, kind="req")
        self.log_send(label)
        if self.pid == self.SEQUENCER:
            self._sequence(req)
        else:
            self.send_to(self.SEQUENCER, req)

    def _sequence(self, req):
        ordered = replace(req, kind="ordered", gseq=self.next_gseq)
        self.next_gseq += 1
        for d in self.others():
            self.send_to(d, ordered)
        self._accept(ordered)

    def _accept(self, m):
        self.buffer[m.gseq] = m
        while self.next_deliver in self.buffer:
            nxt = self.buffer.pop(self.next_deliver)
            self.next_deliver += 1
            self.deliver(nxt)

    def receive(self, m):
        if m.kind == "req":
            self._sequence(m)
        else:
            self._accept(m)


PROTOCOLS = {
    "raw": NoOrdering,
    "fifo": FifoOrdering,
    "causal": CausalOrdering,
    "total": TotalOrdering,
}
