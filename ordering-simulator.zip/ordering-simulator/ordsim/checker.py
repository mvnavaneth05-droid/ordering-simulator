"""Independent verification of ordering guarantees from the event log only.

The checker knows nothing about protocol internals (no vector clocks, no
sequence numbers). It rebuilds ground truth -- the happens-before relation --
from "send" and "deliver" events alone.
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from typing import Dict, List, Set, Tuple


@dataclass
class Report:
    fifo: List[Tuple[int, str, str]] = field(default_factory=list)      # (pid, delivered_first, sent_earlier)
    causal: List[Tuple[int, str, str]] = field(default_factory=list)    # (pid, delivered_first, its_cause)
    total: List[Tuple[str, str, List[int], List[int]]] = field(default_factory=list)
    missing: List[Tuple[int, str]] = field(default_factory=list)        # (pid, label) never/dup delivered

    fifo_ok = property(lambda s: not s.fifo)
    causal_ok = property(lambda s: not s.causal)
    total_ok = property(lambda s: not s.total)
    complete = property(lambda s: not s.missing)


def analyze(log, n: int) -> Report:
    r = Report()
    sends: Dict[int, List[str]] = defaultdict(list)
    sender: Dict[str, int] = {}
    orders: Dict[int, List[str]] = defaultdict(list)

    # Ground-truth happens-before: deps[m] = every message that causally precedes m.
    know: Dict[int, Set[str]] = defaultdict(set)
    deps: Dict[str, frozenset] = {}
    for e in log:
        if e.kind == "send":
            deps[e.label] = frozenset(know[e.pid])
            know[e.pid].add(e.label)
            sends[e.pid].append(e.label)
            sender[e.label] = e.pid
        elif e.kind == "deliver":
            know[e.pid] |= deps[e.label] | {e.label}
            orders[e.pid].append(e.label)

    rank = {l: i for p in sends for i, l in enumerate(sends[p])}
    pos = {p: {l: i for i, l in enumerate(orders[p])} for p in range(n)}

    # completeness: every message delivered exactly once everywhere
    for p in range(n):
        for l in sender:
            if orders[p].count(l) != 1:
                r.missing.append((p, l))

    # FIFO: messages from one sender must be delivered in send order
    for p in range(n):
        for s in range(n):
            seen = [l for l in orders[p] if sender[l] == s]
            for i in range(len(seen)):
                for j in range(i + 1, len(seen)):
                    if rank[seen[i]] > rank[seen[j]]:
                        r.fifo.append((p, seen[i], seen[j]))

    # Causal: if a -> b then everyone delivers a before b
    for p in range(n):
        for b in orders[p]:
            for a in deps[b]:
                if a in pos[p] and pos[p][a] > pos[p][b]:
                    r.causal.append((p, b, a))

    # Total: all processes agree on the relative order of every pair
    labels = sorted(sender)
    for i, a in enumerate(labels):
        for b in labels[i + 1:]:
            a_first = [p for p in range(n) if a in pos[p] and b in pos[p] and pos[p][a] < pos[p][b]]
            b_first = [p for p in range(n) if a in pos[p] and b in pos[p] and pos[p][b] < pos[p][a]]
            if a_first and b_first:
                r.total.append((a, b, a_first, b_first))
    return r
