"""CLI:  python -m ordsim {demo|run|random|stress} ..."""
from __future__ import annotations

import argparse

from .checker import analyze
from .protocols import PROTOCOLS
from .scenarios import SCENARIOS, run_random, run_scenario

OK, BAD = "\u2713", "\u2717"


def trace(sim):
    print("\n  time  proc  event    message")
    for e in sim.log:
        extra = f"  ({e.note})" if e.kind == "recv" and e.note != "data" else ""
        print(f"{e.time:6.2f}  P{e.pid}    {e.kind:<8} {e.label}{extra}")


def orders(sim):
    print("\nDelivery order per process:")
    for p in sim.procs:
        print(f"  P{p.pid}: " + "  ->  ".join(p.delivered))


def verdict(sim, detail=True):
    r = analyze(sim.log, sim.n)
    print(f"\nFIFO {OK if r.fifo_ok else BAD}   Causal {OK if r.causal_ok else BAD}   "
          f"Total {OK if r.total_ok else BAD}   Complete {OK if r.complete else BAD}")
    if detail:
        for p, first, earlier in r.fifo[:3]:
            print(f"  FIFO   : P{p} delivered {first} before {earlier} (sent earlier by same process)")
        for p, first, cause in r.causal[:3]:
            print(f"  CAUSAL : P{p} delivered {first} before its cause {cause}")
        for a, b, af, bf in r.total[:3]:
            print(f"  TOTAL  : {a}<{b} at {['P%d' % x for x in af]}, but {b}<{a} at {['P%d' % x for x in bf]}")
    return r


def cmd_demo(_):
    for name, sc in SCENARIOS.items():
        print(f"\n=== {sc.title}: {sc.description}")
        print(f"{'protocol':<10}{'FIFO':^8}{'Causal':^8}{'Total':^8}")
        for proto in PROTOCOLS:
            r = analyze(run_scenario(name, proto).log, sc.n)
            f = lambda ok: OK if ok else BAD
            print(f"{proto:<10}{f(r.fifo_ok):^8}{f(r.causal_ok):^8}{f(r.total_ok):^8}")


def cmd_run(a):
    sim = run_scenario(a.scenario, a.protocol, a.seed)
    sc = SCENARIOS[a.scenario]
    print(f"{sc.title} -- protocol: {a.protocol}\n{sc.description}")
    if a.trace:
        trace(sim)
    orders(sim)
    verdict(sim)


def cmd_random(a):
    sim = run_random(a.protocol, a.n, a.msgs, a.seed, a.reply)
    print(f"random workload -- protocol: {a.protocol}, n={a.n}, msgs={a.msgs}, seed={a.seed}")
    if a.trace:
        trace(sim)
    orders(sim)
    verdict(sim)


def cmd_stress(a):
    print(f"{a.runs} random runs per protocol (n={a.n}, msgs={a.msgs}); runs that VIOLATE each property:")
    print(f"{'protocol':<10}{'FIFO':>8}{'Causal':>8}{'Total':>8}{'Incomplete':>12}")
    for proto in PROTOCOLS:
        c = [0, 0, 0, 0]
        for seed in range(a.runs):
            r = analyze(run_random(proto, a.n, a.msgs, seed).log, a.n)
            c[0] += not r.fifo_ok; c[1] += not r.causal_ok
            c[2] += not r.total_ok; c[3] += not r.complete
        print(f"{proto:<10}{c[0]:>8}{c[1]:>8}{c[2]:>8}{c[3]:>12}")


def main():
    ap = argparse.ArgumentParser(prog="ordsim", description=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("demo", help="all scenarios x all protocols").set_defaults(fn=cmd_demo)

    r = sub.add_parser("run", help="one scenario, one protocol")
    r.add_argument("scenario", choices=SCENARIOS)
    r.add_argument("--protocol", "-p", choices=PROTOCOLS, default="raw")
    r.add_argument("--seed", type=int, default=0)
    r.add_argument("--trace", "-t", action="store_true")
    r.set_defaults(fn=cmd_run)

    q = sub.add_parser("random", help="random workload")
    q.add_argument("--protocol", "-p", choices=PROTOCOLS, default="raw")
    q.add_argument("--n", type=int, default=4)
    q.add_argument("--msgs", type=int, default=10)
    q.add_argument("--reply", type=float, default=0.4)
    q.add_argument("--seed", type=int, default=1)
    q.add_argument("--trace", "-t", action="store_true")
    q.set_defaults(fn=cmd_random)

    s = sub.add_parser("stress", help="many random runs, count violations")
    s.add_argument("--runs", type=int, default=200)
    s.add_argument("--n", type=int, default=4)
    s.add_argument("--msgs", type=int, default=12)
    s.set_defaults(fn=cmd_stress)

    a = ap.parse_args()
    a.fn(a)


if __name__ == "__main__":
    main()
