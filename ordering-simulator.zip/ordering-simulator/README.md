# Message-Ordering Simulator (FIFO · Causal · Total)

A discrete-event simulator that runs the same workload under four delivery
protocols on a network that reorders messages, then **verifies** each
guarantee with an independent checker.

## Run
Python 3.8+, no dependencies.

    python -m ordsim demo                       # 3 scenarios x 4 protocols
    python -m ordsim run causal -p raw -t       # one scenario, with event trace
    python -m ordsim run causal -p causal -t    # same, fixed by vector clocks
    python -m ordsim random -p total -t         # random workload with replies
    python -m ordsim stress --runs 200          # violation counts over many runs
    python -m unittest discover -s tests        # test suite

## Design
| File | Role |
|---|---|
| `core.py` | Event queue, `Message`, `Process`, network (random delay per message, so links are **non-FIFO**; delays can be pinned per message for scenarios) |
| `protocols.py` | The four protocols (below) |
| `checker.py` | Verifies guarantees from the send/deliver log only |
| `scenarios.py` | Deterministic counter-examples + random workload with reactive replies (creates real causal chains) |
| `__main__.py` | CLI |

### Protocols
* **raw** – deliver on arrival. Guarantees nothing.
* **fifo** – per-sender sequence numbers + hold-back queue; deliver sender's messages in order.
* **causal** – Birman–Schiper–Stephenson vector clocks. Message `m` from `s` is delivered when
  `m.vc[s] == vc[s]+1` and `m.vc[k] <= vc[k]` for all `k != s`; otherwise held back.
* **total** – fixed sequencer (P0) assigns global sequence numbers; all processes (sender included)
  deliver strictly in that order.

### Checker (ground truth)
Rebuilds the *happens-before* relation from the log (a message is causally after everything its
sender had sent or delivered before sending it, transitively), then checks:
* **FIFO**: per sender, delivery order = send order
* **Causal**: if `a -> b`, no process delivers `b` before `a`
* **Total**: no two processes deliver a pair of messages in opposite orders
* **Complete**: every message delivered exactly once everywhere

## Results (`python -m ordsim stress --runs 200`)
Number of runs (of 200) violating each property:

| protocol | FIFO | Causal | Total |
|---|---|---|---|
| raw | 200 | 200 | 200 |
| fifo | 0 | 187 | 200 |
| causal | 0 | 0 | 200 |
| total (sequencer) | 198 | 198 | 0 |

Takeaways:
1. **Causal ⇒ FIFO** (causal row has 0 FIFO violations), but **FIFO ⇏ causal**.
2. **Causal ⇏ total**: concurrent messages may still be seen in different orders.
3. **Total ⇏ FIFO/causal**: the sequencer fixes *one* order for everybody, but that order can
   contradict send order when requests reach the sequencer out of order.

## Extensions
* Causal + total (sequencer delivers requests causally before numbering them), or Lamport/ISIS total order
* Message loss/retransmission, crash of the sequencer, FIFO links as a toggle
* Visualisation (space-time diagram) from `sim.log`
