import os, sys, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from ordsim.checker import analyze
from ordsim.scenarios import SCENARIOS, run_random, run_scenario


class ScenarioTests(unittest.TestCase):
    def rep(self, sc, proto):
        return analyze(run_scenario(sc, proto).log, SCENARIOS[sc].n)

    def test_raw_violates_everything(self):
        self.assertFalse(self.rep("fifo", "raw").fifo_ok)
        self.assertFalse(self.rep("causal", "raw").causal_ok)
        self.assertFalse(self.rep("total", "raw").total_ok)

    def test_fifo_fixes_fifo_not_causal(self):
        self.assertTrue(self.rep("fifo", "fifo").fifo_ok)
        self.assertFalse(self.rep("causal", "fifo").causal_ok)

    def test_causal_implies_fifo_but_not_total(self):
        for sc in SCENARIOS:
            r = self.rep(sc, "causal")
            self.assertTrue(r.fifo_ok and r.causal_ok and r.complete)
        self.assertFalse(self.rep("total", "causal").total_ok)

    def test_total_is_total_but_not_fifo(self):
        for sc in SCENARIOS:
            r = self.rep(sc, "total")
            self.assertTrue(r.total_ok and r.complete)
        self.assertFalse(self.rep("fifo", "total").fifo_ok)


class RandomProperty(unittest.TestCase):
    RUNS = 60

    def each(self, proto):
        for seed in range(self.RUNS):
            yield seed, analyze(run_random(proto, 4, 12, seed).log, 4)

    def test_all_complete(self):
        for proto in ("raw", "fifo", "causal", "total"):
            for seed, r in self.each(proto):
                self.assertTrue(r.complete, (proto, seed))

    def test_fifo_protocol(self):
        for seed, r in self.each("fifo"):
            self.assertTrue(r.fifo_ok, seed)

    def test_causal_protocol(self):
        for seed, r in self.each("causal"):
            self.assertTrue(r.fifo_ok and r.causal_ok, seed)

    def test_total_protocol(self):
        for seed, r in self.each("total"):
            self.assertTrue(r.total_ok, seed)

    def test_raw_is_actually_broken(self):
        bad = sum(not r.causal_ok for _, r in self.each("raw"))
        self.assertGreater(bad, 0)


if __name__ == "__main__":
    unittest.main()
